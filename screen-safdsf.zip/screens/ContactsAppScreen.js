import { SafeAreaView } from 'react-native-safe-area-context';
import React from 'react';
import { View, Text, TouchableOpacity, FlatList } from 'react-native';
import { globalStyles } from '../styles';

export default function ContactsAppScreen({ navigation, route }) {
  const { practiceTopic, onPracticeComplete } = route.params || {};
  const contacts = ['Alice Johnson', 'Bob Smith', 'Charlie Davis', 'Diana Lee'];

  const handleCallContact = (contact) => {
    if (practiceTopic === 'Call a Contact') {
      onPracticeComplete && onPracticeComplete();
    } else {
      alert(`Calling ${contact}...`);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        Contacts
      </Text>

      <FlatList
        data={contacts}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              padding: 15,
              backgroundColor: '#f2f2f2',
              borderRadius: 12,
              marginBottom: 10,
            }}
            onPress={() => handleCallContact(item)}
          >
            <Text style={{ fontSize: 18 }}>{item}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Home Button */}
      <TouchableOpacity
        style={{
          position: 'absolute',
          bottom: 20,
          alignSelf: 'center',
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: '#ddd',
          justifyContent: 'center',
          alignItems: 'center',
        }}
        onPress={() => navigation.goBack()}
      >
        <Text style={{ fontSize: 24 }}>⬤</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
