import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, Modal } from 'react-native';
import { globalStyles } from '../styles';

export default function SimulatedIphoneScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};
  const isPracticeMode = !!practiceTopic;

  const [practiceComplete, setPracticeComplete] = useState(false);

  const apps = [
    { name: 'Settings', screen: 'SettingsAppScreen' },
    { name: 'Camera', screen: 'CameraAppScreen' },
    { name: 'Contacts', screen: 'ContactsAppScreen' },
    { name: 'Safari', screen: 'SafariAppScreen' },
  ];

  const handleOpenApp = (item) => {
    navigation.navigate(item.screen, {
      practiceTopic,
      onPracticeComplete: () => setPracticeComplete(true),
    });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      {/* Practice task bar */}
      {isPracticeMode && (
        <View style={{
          backgroundColor: '#f2f2f2',
          padding: 8,
          alignItems: 'center',
          justifyContent: 'center',
          borderBottomWidth: 1,
          borderBottomColor: '#ddd',
        }}>
          <Text style={{ color: '#333', fontSize: 14 }}>
            Practicing: {practiceTopic}
          </Text>
        </View>
      )}

      {/* App grid */}
      <FlatList
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: 'center',
          alignItems: 'center',
          paddingVertical: 40,
        }}
        data={apps}
        keyExtractor={(item) => item.name}
        numColumns={2}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              width: 100,
              height: 100,
              margin: 15,
              borderRadius: 24,
              backgroundColor: '#eee',
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.3,
              shadowRadius: 4,
              elevation: 5,
            }}
            onPress={() => handleOpenApp(item)}
          >
            <Text style={{ color: '#333', fontSize: 16 }}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Home indicator bar (always show, iPhone style) */}
      <View style={{
        position: 'absolute',
        bottom: 10,
        alignSelf: 'center',
        width: 120,
        height: 5,
        borderRadius: 3,
        backgroundColor: '#ccc',
      }} />

      {/* Practice Complete Modal */}
      <Modal
        visible={practiceComplete}
        transparent
        animationType="fade"
        onRequestClose={() => setPracticeComplete(false)}
      >
        <View style={{
          flex: 1,
          backgroundColor: 'rgba(0,0,0,0.5)',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
          <View style={{
            backgroundColor: '#fff',
            padding: 20,
            borderRadius: 16,
            alignItems: 'center',
          }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 10 }}>
              🎉 Task Completed!
            </Text>
            <TouchableOpacity
              style={[globalStyles.button, { marginTop: 10 }]}
              onPress={() => {
                setPracticeComplete(false);
                navigation.navigate('PracticeMode');
              }}
            >
              <Text style={globalStyles.buttonText}>Return to Practice Mode</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
