import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Switch } from 'react-native';
import { globalStyles } from '../styles';

export default function SettingsAppScreen({ navigation, route }) {
  const { practiceTopic, onPracticeComplete } = route.params || {};
  const [wifiEnabled, setWifiEnabled] = useState(false);

  const handleToggleWifi = (value) => {
    setWifiEnabled(value);

    if (practiceTopic === 'Connect to Wi-Fi' && value) {
      onPracticeComplete && onPracticeComplete();
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        Settings
      </Text>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: 15,
          borderBottomWidth: 1,
          borderBottomColor: '#ccc',
        }}
      >
        <Text style={{ fontSize: 18 }}>Wi-Fi</Text>
        <Switch
          value={wifiEnabled}
          onValueChange={handleToggleWifi}
        />
      </View>

      {/* Home Button */}
      <TouchableOpacity
        style={{
          position: 'absolute',
          bottom: 20,
          alignSelf: 'center',
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: '#ddd',
          justifyContent: 'center',
          alignItems: 'center',
        }}
        onPress={() => navigation.goBack()}
      >
        <Text style={{ fontSize: 24 }}>⬤</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
