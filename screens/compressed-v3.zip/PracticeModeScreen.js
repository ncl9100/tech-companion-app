import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import guides from '../guides.json';

export default function PracticeModeScreen({ navigation }) {
  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.guideItem}
      onPress={() =>
        navigation.navigate('GuidePlayerScreen', { guideId: item.guide_id })
      }
    >
      <Text style={styles.guideTitle}>{item.title}</Text>
      <Text style={styles.guideCategory}>{item.category}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Practice Mode</Text>
      <FlatList
        data={guides}
        keyExtractor={(item) => item.guide_id}
        renderItem={renderItem}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  guideItem: {
    padding: 16,
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    marginBottom: 10,
  },
  guideTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  guideCategory: {
    fontSize: 14,
    color: '#666',
  },
});
