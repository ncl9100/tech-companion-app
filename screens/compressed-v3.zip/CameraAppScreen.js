import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles';

export default function CameraAppScreen({ navigation, route }) {
  const { practiceTopic, onPracticeComplete } = route.params || {};
  const [photoTaken, setPhotoTaken] = useState(false);

  const handleTakePhoto = () => {
    setPhotoTaken(true);

    if (practiceTopic === 'Take a Photo') {
      onPracticeComplete && onPracticeComplete();
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }}>
      <TouchableOpacity
        style={{
          width: 80,
          height: 80,
          borderRadius: 40,
          borderWidth: 4,
          borderColor: '#fff',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#aaa',
        }}
        onPress={handleTakePhoto}
      >
        <Text style={{ color: '#fff' }}>{photoTaken ? '📸' : 'Take'}</Text>
      </TouchableOpacity>

      {/* Home Button */}
      <TouchableOpacity
        style={{
          position: 'absolute',
          bottom: 20,
          alignSelf: 'center',
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: '#ddd',
          justifyContent: 'center',
          alignItems: 'center',
        }}
        onPress={() => navigation.goBack()}
      >
        <Text style={{ fontSize: 24 }}>⬤</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
