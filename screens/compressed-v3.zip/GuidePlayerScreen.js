import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import guides from '../guides.json';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

export default function GuidePlayerScreen({ route, navigation }) {
  const { guideId } = route.params;
  const guide = guides.find(g => g.guide_id === guideId);

  // SAFETY CHECK: if guide not found → do not crash
  if (!guide) {
    console.error(`Guide with id '${guideId}' not found!`);
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>Guide not found!</Text>
        <Text style={styles.instruction}>
          The guide with ID '{guideId}' was not found. Please check your guides.json.
        </Text>
        <TouchableOpacity
          style={styles.homeButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.homeButtonText}>Go Back</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const currentStep =
    guide.steps.length > 0 ? guide.steps[currentStepIndex] : null;

  const handleHotspotPress = () => {
    if (currentStepIndex < guide.steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      alert('🎉 You have completed this guide!');
      navigation.goBack();
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>{guide.title}</Text>
      {currentStep ? (
        <>
          <Text style={styles.instruction}>{currentStep.instruction}</Text>

          <View style={styles.simulatedIphoneContainer}>
            {/* Placeholder — here you will later render your simulated iPhone view */}
            <View style={styles.simulatedScreen}>
              <Text style={{ color: '#999' }}>
                [ Simulated iPhone screen goes here ]
              </Text>
            </View>

            {Array.isArray(currentStep.hotspots) &&
              currentStep.hotspots.map((hotspot, index) => (
                <TouchableOpacity
                  key={index}
                  style={{
                    position: 'absolute',
                    left: hotspot.x * screenWidth,
                    top: hotspot.y * screenHeight,
                    width: hotspot.width * screenWidth,
                    height: hotspot.height * screenHeight,
                    backgroundColor: 'rgba(255,255,255,0.01)' // transparent tap area
                  }}
                  onPress={handleHotspotPress}
                />
              ))}
          </View>
        </>
      ) : (
        <Text style={styles.instruction}>No steps available for this guide.</Text>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000', // black background to simulate phone frame
    padding: 12
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8
  },
  instruction: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 12
  },
  simulatedIphoneContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative'
  },
  simulatedScreen: {
    width: screenWidth * 0.95,
    height: screenHeight * 0.7,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#222'
  },
  homeButton: {
    marginTop: 20,
    backgroundColor: '#444',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  homeButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});
