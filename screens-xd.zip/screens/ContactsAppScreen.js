import { SafeAreaView } from 'react-native-safe-area-context';
import React from 'react';
import { View, Text, TouchableOpacity, FlatList } from 'react-native';
import { globalStyles } from '../styles';

export default function ContactsAppScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};

  const contacts = [
    'Alice Johnson',
    'Bob Smith',
    'Charlie Davis',
    'Diana Lee',
  ];

  const handleCallContact = (contact) => {
    if (practiceTopic === 'Call a Contact') {
      alert(`✅ Called ${contact}! Practice task complete.`);
    } else {
      alert(`Calling ${contact}...`);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        Contacts
      </Text>

      <FlatList
        data={contacts}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              padding: 15,
              backgroundColor: '#f2f2f2',
              borderRadius: 12,
              marginBottom: 10,
            }}
            onPress={() => handleCallContact(item)}
          >
            <Text style={{ fontSize: 18 }}>{item}</Text>
          </TouchableOpacity>
        )}
      />

      <TouchableOpacity
        style={[globalStyles.button, { marginTop: 30 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={globalStyles.buttonText}>Go Back</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
