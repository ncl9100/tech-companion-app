import { SafeAreaView } from 'react-native-safe-area-context';
import React from 'react';
import { View, Text, TouchableOpacity, FlatList } from 'react-native';
import { globalStyles } from '../styles';

export default function SimulatedIphoneScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};
  const isPracticeMode = !!practiceTopic;

  const apps = [
    { name: 'Settings', screen: 'SettingsAppScreen' },
    { name: 'Camera', screen: 'CameraAppScreen' },
    { name: 'Contacts', screen: 'ContactsAppScreen' },
    { name: 'Safari', screen: 'SafariAppScreen' },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#000' }}>
      {/* Practice task bar */}
      {isPracticeMode && (
        <View style={{
          backgroundColor: '#222',
          padding: 8,
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          <Text style={{ color: '#ccc', fontSize: 14 }}>
            Practicing: {practiceTopic}
          </Text>
        </View>
      )}

      <FlatList
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: 'center',
          alignItems: 'center',
          paddingVertical: 40,
        }}
        data={apps}
        keyExtractor={(item) => item.name}
        numColumns={2}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              width: 120,
              height: 120,
              margin: 15,
              borderRadius: 24,
              backgroundColor: '#333',
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.5,
              shadowRadius: 4,
              elevation: 5,
            }}
            onPress={() => navigation.navigate(item.screen, { practiceTopic })}
          >
            {/* Later you can replace with an icon */}
            <Text style={{ color: '#fff', fontSize: 16 }}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Exit button — only show if NOT in Practice mode */}
      {!isPracticeMode && (
        <TouchableOpacity
          style={{
            backgroundColor: '#333',
            margin: 10,
            padding: 12,
            borderRadius: 16,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={() => navigation.navigate('PracticeMode')}
        >
          <Text style={{ color: '#fff', fontSize: 16 }}>Exit iPhone → Practice Mode</Text>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}
