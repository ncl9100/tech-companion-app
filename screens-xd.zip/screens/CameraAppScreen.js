import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles';

export default function CameraAppScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};
  const [photoTaken, setPhotoTaken] = useState(false);

  const handleTakePhoto = () => {
    setPhotoTaken(true);

    if (practiceTopic === 'Take a Photo') {
      alert('✅ Photo taken! Practice task complete.');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }}>
      <TouchableOpacity
        style={{
          width: 80,
          height: 80,
          borderRadius: 40,
          borderWidth: 4,
          borderColor: '#fff',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#aaa',
        }}
        onPress={handleTakePhoto}
      >
        <Text style={{ color: '#fff' }}>{photoTaken ? '📸' : 'Take'}</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[globalStyles.button, { marginTop: 30 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={globalStyles.buttonText}>Go Back</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
