import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function LearnBasicsScreen({ navigation }) {
  const topics = [
    { title: 'Internet' },
    { title: 'Settings' },
    // Add more topics here if needed
  ];

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.topicItem}
      onPress={() => navigation.navigate('LearnBasicsGuide', { topic: item })}
    >
      <Text style={styles.topicTitle}>{item.title}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Learn Basics</Text>
      <FlatList
        data={topics}
        keyExtractor={item => item.title}
        renderItem={renderItem}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12
  },
  topicItem: {
    padding: 16,
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    marginBottom: 10
  },
  topicTitle: {
    fontSize: 18,
    fontWeight: 'bold'
  }
});
