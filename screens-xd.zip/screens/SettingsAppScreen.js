import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Switch } from 'react-native';
import { globalStyles } from '../styles';

export default function SettingsAppScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};
  const [wifiEnabled, setWifiEnabled] = useState(false);

  const handleToggleWifi = (value) => {
    setWifiEnabled(value);

    if (practiceTopic === 'Connect to Wi-Fi' && value) {
      alert('✅ Wi-Fi connected! Practice task complete.');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        Settings
      </Text>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: 15,
          borderBottomWidth: 1,
          borderBottomColor: '#ccc',
        }}
      >
        <Text style={{ fontSize: 18 }}>Wi-Fi</Text>
        <Switch
          value={wifiEnabled}
          onValueChange={handleToggleWifi}
        />
      </View>

      <TouchableOpacity
        style={[globalStyles.button, { marginTop: 30 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={globalStyles.buttonText}>Go Back</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
