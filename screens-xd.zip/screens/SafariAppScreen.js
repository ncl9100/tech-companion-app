import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles';

export default function SafariAppScreen({ navigation, route }) {
  const { practiceTopic } = route.params || {};
  const [url, setUrl] = useState('');

  const handleGoToUrl = () => {
    if (practiceTopic === 'Open a Website' && url.length > 0) {
      alert(`✅ Opened "${url}"! Practice task complete.`);
    } else if (url.length > 0) {
      alert(`Opening "${url}"...`);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        Safari
      </Text>

      <TextInput
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          borderRadius: 12,
          padding: 12,
          fontSize: 16,
          marginBottom: 20,
        }}
        placeholder="Enter website URL"
        value={url}
        onChangeText={setUrl}
      />

      <TouchableOpacity
        style={[globalStyles.button]}
        onPress={handleGoToUrl}
      >
        <Text style={globalStyles.buttonText}>Go</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[globalStyles.button, { marginTop: 30 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={globalStyles.buttonText}>Go Back</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
